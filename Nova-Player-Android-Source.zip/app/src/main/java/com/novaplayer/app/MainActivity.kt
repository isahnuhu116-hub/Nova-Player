package com.novaplayer.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class VideoItem(val title: String, val uri: Uri, val duration: Long, val size: Long)

class MainActivity : Activity() {
    private lateinit var list: RecyclerView
    private lateinit var status: TextView
    private val videos = mutableListOf<VideoItem>()
    private val permissionRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 16, 24)
        window.navigationBarColor = android.graphics.Color.rgb(13, 16, 24)
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 12)
            setBackgroundColor(android.graphics.Color.rgb(13, 16, 24))
        }
        val heading = TextView(this).apply {
            text = "NOVA PLAYER"
            textSize = 25f
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "YOUR MOVIES. YOUR CONTROL."
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(android.graphics.Color.rgb(143, 155, 179))
            setPadding(0, 4, 0, 22)
        }
        status = TextView(this).apply {
            text = "Your video library"
            textSize = 14f
            setTextColor(android.graphics.Color.rgb(190, 200, 218))
            setPadding(0, 4, 0, 12)
        }
        list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity) }
        base.addView(heading)
        base.addView(subtitle)
        base.addView(status)
        base.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(base)
        checkPermissionAndLoad()
    }

    private fun checkPermissionAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadVideos()
        else ActivityCompat.requestPermissions(this, arrayOf(permission), permissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadVideos()
        else status.text = "Allow video access to show movies stored on your phone."
    }

    private fun loadVideos() {
        videos.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        val cursor: Cursor? = contentResolver.query(collection, projection, null, null, sort)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                videos.add(VideoItem(it.getString(nameCol) ?: "Video", Uri.withAppendedPath(collection, id.toString()), it.getLong(durationCol), it.getLong(sizeCol)))
            }
        }
        status.text = if (videos.isEmpty()) "No videos found. Add movies to your phone and refresh." else "${videos.size} VIDEOS"
        list.adapter = VideoAdapter(videos) { item ->
            startActivity(Intent(this, PlayerActivity::class.java).setData(item.uri).putExtra("title", item.title))
        }
    }

    private class VideoAdapter(private val items: List<VideoItem>, private val onTap: (VideoItem) -> Unit) : RecyclerView.Adapter<VideoAdapter.Holder>() {
        class Holder(val label: TextView) : RecyclerView.ViewHolder(label)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val tv = TextView(parent.context).apply {
                textSize = 15f
                setTextColor(android.graphics.Color.WHITE)
                setPadding(16, 19, 16, 19)
                setBackgroundColor(android.graphics.Color.rgb(25, 31, 44))
                gravity = Gravity.CENTER_VERTICAL
            }
            val lp = RecyclerView.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = 9
            tv.layoutParams = lp
            return Holder(tv)
        }
        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = items[position]
            val mins = item.duration / 60000
            holder.label.text = "▶   ${item.title}\n      ${mins} min  •  ${item.size / (1024 * 1024)} MB"
            holder.label.setOnClickListener { onTap(item) }
        }
        override fun getItemCount() = items.size
    }
}
