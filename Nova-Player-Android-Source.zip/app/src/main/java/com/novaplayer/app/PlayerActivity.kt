package com.novaplayer.app

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        val uri = intent.data ?: run { finish(); return }
        val root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        val title = TextView(this).apply {
            text = intent.getStringExtra("title") ?: "Nova Player"
            textSize = 15f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0x99000000.toInt())
        }
        val view = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(-1, -1)
            useController = true
        }
        root.addView(view)
        root.addView(title, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.setMediaItem(MediaItem.fromUri(uri))
            it.prepare()
            it.playWhenReady = true
        }
    }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
